package com.springboot.service;

public interface Animal {

	public String characteristics();

}
